module.exports = {
    secret: "bezkoder-secret-key",
    tokenExpiry: 3600,
    emailService : "gmail",
    emailUser : "mouradtlili66@gmail.com",
    emailPassword: "Mourad6666"
  };