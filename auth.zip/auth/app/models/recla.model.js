const mongoose = require("mongoose")
const Status = require("./status.model")

const Recla = mongoose.model(
    "Recla",
    new mongoose.Schema(
        {
        UserId : String,
        CreatedAt : {
            type  : Date,
            default  : Date.now
        },
        Product : {
        type : mongoose.Schema.Types.ObjectId,
        ref : "Product"
        },
        Status : [
            {
        type : mongoose.Schema.Types.ObjectId,
        ref  : "Status"
            }
                ]

        }
    )
)
module.exports = Recla